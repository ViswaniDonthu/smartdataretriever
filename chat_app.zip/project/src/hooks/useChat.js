import { useState, useCallback } from 'react';
import { generateId, generateChatTitle, simulateAIResponse } from '../utils/chatUtils';

export const useChat = () => {
  const [sessions, setSessions] = useState([]);
  const [currentSessionId, setCurrentSessionId] = useState(null);

  const currentSession = sessions.find(session => session.id === currentSessionId);

  const createNewChat = useCallback(() => {
    const newSession = {
      id: generateId(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
  }, []);

  const sendMessage = useCallback(async (content) => {
    if (!currentSessionId) return;

    const userMessage = {
      id: generateId(),
      content,
      sender: 'user',
      timestamp: new Date(),
    };

    // Update session with user message
    setSessions(prev => prev.map(session => {
      if (session.id === currentSessionId) {
        const updatedMessages = [...session.messages, userMessage];
        const title = session.messages.length === 0 ? generateChatTitle(content) : session.title;
        
        return {
          ...session,
          title,
          messages: updatedMessages,
          updatedAt: new Date(),
        };
      }
      return session;
    }));

    // Simulate AI response
    setTimeout(() => {
      const aiMessage = {
        id: generateId(),
        content: simulateAIResponse(content),
        sender: 'ai',
        timestamp: new Date(),
      };

      setSessions(prev => prev.map(session => {
        if (session.id === currentSessionId) {
          return {
            ...session,
            messages: [...session.messages, aiMessage],
            updatedAt: new Date(),
          };
        }
        return session;
      }));
    }, 1000);
  }, [currentSessionId]);

  const selectChat = useCallback((sessionId) => {
    setCurrentSessionId(sessionId);
  }, []);

  return {
    sessions,
    currentSession,
    createNewChat,
    sendMessage,
    selectChat,
  };
};